// models/User.ts
import mongoose, { Schema } from "mongoose";
import argon2 from "argon2";

const UserSchema = new Schema(
  {
    name: String,
    email: {
      type: String,
      required: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

// Méthode de hashage avec Argon2
UserSchema.methods.hashPassword = async function (password: string) {
  const hashingConfig = {
    memoryCost: 2048, // Utilisation de la mémoire
    timeCost: 3, // Nombre d'itérations
    parallelism: 1, // Degré de parallélisme
    type: argon2.argon2id, // Variante la plus sécurisée
  };
  return await argon2.hash(password, hashingConfig);
};

// Méthode de vérification avec Argon2
UserSchema.methods.comparePassword = async function (
  candidatePassword: string
) {
  try {
    return await argon2.verify(this.password, candidatePassword);
  } catch (error) {
    console.error("Erreur lors de la vérification du mot de passe:", error);
    return false;
  }
};

export default mongoose.models.User || mongoose.model("User", UserSchema);
