import mongoose, { Schema } from "mongoose";

const AttachmentSchema = new Schema({
  filename: String,
  fileType: String,
  fileUrl: String,
  uploadedAt: { type: Date, default: Date.now },
});

const NoteSchema = new Schema(
  {
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
    },
    content: {
      type: String,
      required: [true, "Content is required"],
    },
    tags: [
      {
        type: String,
        trim: true,
      },
    ],
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    attachments: [AttachmentSchema],
  },
  {
    timestamps: true,
  }
);

export default mongoose.models.Note || mongoose.model("Note", NoteSchema);
