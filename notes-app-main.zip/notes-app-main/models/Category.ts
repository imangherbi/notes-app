import mongoose, { Schema } from "mongoose";

const CategorySchema = new Schema(
  {
    name: {
      type: String,
      required: [true, "Le nom est requis"],
      trim: true,
    },
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    courses: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Course",
        default: [],
      },
    ],
  },
  {
    timestamps: true,
  }
);

// Middleware pour peupler automatiquement les cours
CategorySchema.pre(["find", "findOne"], function (next) {
  this.populate("courses");
  next();
});

export default mongoose.models.Category ||
  mongoose.model("Category", CategorySchema);
