import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Spinner from "@/components/Spinner";

export function withAuth<P extends object>(
  WrappedComponent: React.ComponentType<P>,
  requireAuth: boolean = true
) {
  return function WithAuthComponent(props: P) {
    const router = useRouter();
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
      const checkAuth = async () => {
        try {
          const user = localStorage.getItem("user");
          const isAuthenticated = !!user;

          if (requireAuth && !isAuthenticated) {
            await router.push("/login");
          } else if (!requireAuth && isAuthenticated) {
            await router.push("/dashboard");
          } else {
            setIsLoading(false);
          }
        } catch (error) {
          console.error("Auth check error:", error);
          setIsLoading(false);
        }
      };

      checkAuth();
    }, [router]);

    if (isLoading) {
      return <Spinner />;
    }

    return <WrappedComponent {...props} />;
  };
}
