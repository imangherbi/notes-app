/** @type {import('next').NextConfig} */
const nextConfig = {
  // Supprimer toute configuration MongoDB si présente
}

module.exports = nextConfig;
