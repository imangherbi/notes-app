// lib/mongodb.ts
// Alternative approach for Next.js compatibility
const mongoose = require("mongoose");

const MONGODB_URI = process.env.MONGODB_URI;
const DB_NAME = "notes-app";

if (!MONGODB_URI) {
  throw new Error(
    "Please define the MONGODB_URI environment variable inside .env.local"
  );
}

// Define global cache type
let cached = global as any;
if (!cached.mongoose) {
  cached.mongoose = { conn: null, promise: null };
}

async function dbConnect() {
  if (cached.mongoose.conn) {
    console.log("Using existing connection");
    return cached.mongoose.conn;
  }

  if (!cached.mongoose.promise) {
    const opts = {
      bufferCommands: false,
      dbName: DB_NAME,
    };

    cached.mongoose.promise = mongoose
      .connect(MONGODB_URI, opts)
      .then((mongoose: any) => {
        console.log(
          "New connection established to MongoDB - Database:",
          DB_NAME
        );
        return mongoose;
      })
      .catch((error: any) => {
        console.error("MongoDB connection error:", error);
        cached.mongoose.promise = null;
        throw error;
      });
  }

  try {
    cached.mongoose.conn = await cached.mongoose.promise;
  } catch (e) {
    cached.mongoose.promise = null;
    throw e;
  }

  return cached.mongoose.conn;
}

export default dbConnect;
