import formidable from 'formidable';
import fs from 'fs/promises';
import path from 'path';
import { Attachment } from '@/types';

export const saveFile = async (file: formidable.File): Promise<Attachment> => {
  try {
    // Créer le dossier attachments s'il n'existe pas
    const uploadDir = path.join(process.cwd(), 'public', 'attachments');
    await fs.mkdir(uploadDir, { recursive: true });

    // Créer un nom de fichier unique
    const timestamp = Date.now();
    const originalName = file.originalFilename || 'unknown';
    const fileExtension = path.extname(originalName);
    const uniqueFilename = `${timestamp}-${Math.random().toString(36).substring(2, 15)}${fileExtension}`;
    
    // Chemin complet du nouveau fichier
    const newPath = path.join(uploadDir, uniqueFilename);

    // Copier le fichier
    await fs.copyFile(file.filepath, newPath);
    
    // Supprimer le fichier temporaire
    await fs.unlink(file.filepath).catch(console.error);

    // Retourner les informations du fichier
    return {
      filename: originalName,
      fileType: file.mimetype || 'application/octet-stream',
      fileUrl: uniqueFilename,
      uploadedAt: new Date()
    };
  } catch (error) {
    console.error('Error saving file:', error);
    throw new Error('Failed to save file');
  }
};

export const deleteFile = async (fileUrl: string): Promise<void> => {
  try {
    const filePath = path.join(process.cwd(), 'public', 'attachments', fileUrl);
    await fs.unlink(filePath);
  } catch (error) {
    console.error('Error deleting file:', error);
    // Ne pas throw d'erreur pour éviter de bloquer la suppression de la note
  }
};

export const validateFile = (file: formidable.File): boolean => {
  // Taille maximale (10MB)
  const maxSize = 10 * 1024 * 1024;
  if (file.size > maxSize) {
    return false;
  }

  // Types de fichiers autorisés
  const allowedTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'
  ];

  return allowedTypes.includes(file.mimetype || '');
};
