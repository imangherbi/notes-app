import mongoose from "mongoose";
import dbConnect from "./mongodb";

export async function initializeCollections() {
  try {
    await dbConnect();
    if (mongoose.connection.readyState !== 1) {
      throw new Error("MongoDB is not connected");
    }

    const db = mongoose.connection.db;
    if (!db) {
      throw new Error("MongoDB database instance is not available");
    }

    const collections = await db.collections();
    const collectionNames = collections.map((c) => c.collectionName);
    const requiredCollections = ["categories", "courses", "notes", "users"];

    for (const collectionName of requiredCollections) {
      if (!collectionNames.includes(collectionName)) {
        await db.createCollection(collectionName);
        console.log(`Collection ${collectionName} created successfully`);
      } else {
        console.log(`Collection ${collectionName} already exists`);
      }
    }
  } catch (error) {
    console.error("Error during collections initialization:", error);
    throw error;
  }
}
