import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { Course } from "@/types";
import Spinner from "@/components/Spinner";
import NoteCard from "@/components/NoteCard";
import { withAuth } from "@/hoc/withAuth";
import NoteModal from "@/components/NoteModal";

function CourseDetailsPage() {
  const router = useRouter();
  const { id } = router.query;
  const [course, setCourse] = useState<Course | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);

  const fetchCourse = async () => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/courses/${id}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message);
      }

      setCourse(data.data);
    } catch (error: any) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddNote = async (data: FormData) => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      data.append("courseId", id as string);
      data.append("userId", user.id);

      const response = await fetch("/api/notes/add", {
        method: "POST",
        body: data,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Error creating note");
      }

      fetchCourse();
      setIsNoteModalOpen(false);
    } catch (error: any) {
      console.error("Error:", error);
      throw error;
    }
  };

  useEffect(() => {
    if (id) {
      fetchCourse();
    }
  }, [id]);

  if (isLoading) return <Spinner />;

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={() => router.back()}
            className="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600"
          >
            Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <button
            onClick={() => router.back()}
            className="flex items-center text-gray-600 hover:text-gray-900"
          >
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Back
          </button>
        </div>

        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">{course?.title}</h1>
          <button
            onClick={() => setIsNoteModalOpen(true)}
            className="px-6 py-3 bg-indigo-500 text-white rounded-lg
              hover:bg-indigo-600 transition-colors duration-200
              flex items-center gap-2 shadow-sm hover:shadow-md"
          >
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 4v16m8-8H4"
              />
            </svg>
            Add Note
          </button>
        </div>

        {course?.notes && course.notes.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {course.notes.map((note) => (
              <NoteCard
                key={note._id}
                note={note}
                onNotesChange={fetchCourse}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12 bg-white rounded-lg shadow-sm">
            <svg
              className="mx-auto h-12 w-12 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 13h6m-3-3v6m5 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No notes</h3>
            <p className="mt-1 text-sm text-gray-500">
              Get started by creating a new note
            </p>
            <div className="mt-6">
              <button
                onClick={() => setIsNoteModalOpen(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent 
                  shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 
                  hover:bg-indigo-700 focus:outline-none focus:ring-2 
                  focus:ring-offset-2 focus:ring-indigo-500"
              >
                <svg
                  className="-ml-1 mr-2 h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 4v16m8-8H4"
                  />
                </svg>
                New Note
              </button>
            </div>
          </div>
        )}

        <NoteModal
          isOpen={isNoteModalOpen}
          onClose={() => setIsNoteModalOpen(false)}
          onSubmit={handleAddNote}
          courseTitle={course?.title || ""}
        />
      </div>
    </div>
  );
}

export default withAuth(CourseDetailsPage);
