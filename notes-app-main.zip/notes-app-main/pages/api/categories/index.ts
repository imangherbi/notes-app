import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Category from "@/models/Category";
import mongoose from "mongoose";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const userId = req.query.userId;

    const categories = await Category.aggregate([
      {
        $match: { createdBy: new mongoose.Types.ObjectId(userId as string) },
      },
      {
        $sort: { createdAt: -1 },
      },
      {
        $lookup: {
          from: "courses",
          localField: "courses",
          foreignField: "_id",
          as: "courses",
          pipeline: [
            {
              $sort: { createdAt: -1 },
            },
            {
              $lookup: {
                from: "notes",
                localField: "notes",
                foreignField: "_id",
                as: "notes",
                pipeline: [
                  {
                    $sort: { createdAt: -1 },
                  },
                ],
              },
            },
          ],
        },
      },
      {
        $project: {
          _id: { $toString: "$_id" },
          name: 1,
          createdBy: { $toString: "$createdBy" },
          createdAt: { $toString: "$createdAt" },
          updatedAt: { $toString: "$updatedAt" },
          courses: {
            $map: {
              input: "$courses",
              as: "course",
              in: {
                _id: { $toString: "$$course._id" },
                title: "$$course.title",
                notes: "$$course.notes",
                createdAt: { $toString: "$$course.createdAt" },
                updatedAt: { $toString: "$$course.updatedAt" },
              },
            },
          },
        },
      },
    ]);

    return res.status(200).json({
      success: true,
      data: categories,
    });
  } catch (error: any) {
    console.error("Error fetching categories:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la récupération des catégories",
    });
  }
}
