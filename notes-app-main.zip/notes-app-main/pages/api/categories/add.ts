import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Category from "@/models/Category";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const { name, userId } = req.body;

    if (!name || !userId) {
      return res.status(400).json({
        success: false,
        message: "Le nom et l'identifiant utilisateur sont requis",
      });
    }

    // Vérifier si une catégorie avec le même nom existe déjà
    const existingCategory = await Category.findOne({
      name,
      createdBy: userId,
    });
    if (existingCategory) {
      return res.status(409).json({
        success: false,
        message: "Une catégorie avec ce nom existe déjà",
      });
    }

    // Créer la nouvelle catégorie
    const newCategory = await Category.create({
      name,
      createdBy: userId,
      courses: [],
    });
    return res.status(201).json({
      success: true,
      message: "Catégorie créée avec succès",
      category: newCategory,
    });
  } catch (error: any) {
    console.error("Error creating category:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la création de la catégorie",
    });
  }
}
