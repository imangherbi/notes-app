import type { NextApiRequest, NextApiResponse } from "next";
import formidable from "formidable";
import fs from "fs/promises";
import path from "path";
import dbConnect from "@/lib/mongodb";
import Note from "@/models/Note";
import Course from "@/models/Course";
import mongoose from "mongoose";
import { saveFile, validateFile } from "@/lib/fileUtils";

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();

    const form = formidable({
      uploadDir: path.join(process.cwd(), "public", "attachments"),
      keepExtensions: true,
      multiples: true,
    });

    const [fields, files] = await form.parse(req);

    // Validate and save attachments
    const attachments = [];
    if (files.attachments) {
      for (const file of Array.isArray(files.attachments)
        ? files.attachments
        : [files.attachments]) {
        if (!validateFile(file)) {
          return res.status(400).json({
            success: false,
            message: "Invalid file type or size",
          });
        }
        const savedFile = await saveFile(file);
        attachments.push(savedFile);
      }
    }

    // Create note with attachments
    const newNote = await Note.create({
      title: fields.title?.[0] ?? "",
      content: fields.content?.[0] ?? "",
      tags: fields.tags ? fields.tags[0].split(",").filter(Boolean) : [],
      userId: new mongoose.Types.ObjectId(fields.userId?.[0]),
      attachments,
    });

    // Ajouter la note au cours
    const courseId = fields.courseId?.[0];
    if (!courseId) {
      throw new Error("Course ID is required");
    }
    await Course.findByIdAndUpdate(courseId, {
      $push: { notes: newNote._id },
    });

    return res.status(201).json({
      success: true,
      note: newNote,
    });
  } catch (error: any) {
    console.error("Error creating note:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Error creating note",
    });
  }
}
