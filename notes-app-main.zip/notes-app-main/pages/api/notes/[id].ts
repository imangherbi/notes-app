import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Note from "@/models/Note";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const { id } = req.query;

    const note = await Note.findById(id)
      .populate("userId", "name email")
      .populate("courseId", "title");

    if (!note) {
      return res.status(404).json({
        success: false,
        message: "Note non trouvée",
      });
    }

    return res.status(200).json({
      success: true,
      note,
    });
  } catch (error: any) {
    console.error("Erreur récupération note:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la récupération de la note",
    });
  }
}
