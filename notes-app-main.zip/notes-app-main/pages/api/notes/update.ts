import type { NextApiRequest, NextApiResponse } from "next";
import formidable from "formidable";
import dbConnect from "@/lib/mongodb";
import Note from "@/models/Note";
import { saveFile } from "@/lib/fileUtils";

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "PUT") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const form = formidable({ multiples: true });
    const [fields, files] = await form.parse(req);
    const { id } = req.query;

    const note = await Note.findById(id);
    if (!note) {
      return res.status(404).json({ message: "Note not found" });
    }

    // Handle attachments
    const attachments = [...note.attachments];
    if (files.attachments) {
      for (const file of Array.isArray(files.attachments)
        ? files.attachments
        : [files.attachments]) {
        const savedFile = await saveFile(file);
        attachments.push(savedFile);
      }
    }

    const updatedNote = await Note.findByIdAndUpdate(
      id,
      {
        title: fields.title?.[0],
        content: fields.content?.[0],
        tags: fields.tags?.[0]?.split(",").filter(Boolean) || [],
        attachments,
      },
      { new: true }
    );

    return res.status(200).json({
      success: true,
      note: updatedNote,
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: error.message || "Error updating note",
    });
  }
}
