import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "../../../lib/mongodb";
import User from "../../../models/User";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const { name, email, password } = req.body;

    // Validation
    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: "Tous les champs sont requis",
      });
    }

    // Vérification email existant
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(409).json({
        success: false,
        message: "Cet email est déjà utilisé",
      });
    }

    // Création de l'utilisateur avec Argon2
    const newUser = new User({
      name,
      email,
    });

    // Hashage du mot de passe avec Argon2
    newUser.password = await newUser.hashPassword(password);
    await newUser.save();

    // Réponse sans le mot de passe
    const userResponse = {
      id: newUser._id,
      name: newUser.name,
      email: newUser.email,
    };

    return res.status(201).json({
      success: true,
      message: "Compte créé avec succès",
      user: userResponse,
    });
  } catch (error: any) {
    console.error("Erreur création utilisateur:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la création du compte",
    });
  }
}
