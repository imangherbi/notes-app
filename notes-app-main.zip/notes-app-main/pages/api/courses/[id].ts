import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Course from "@/models/Course";
import Note from "@/models/Note"; // Add this import
import mongoose from "mongoose";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "GET") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const { id } = req.query;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({ message: "Invalid course ID" });
    }

    // Get course with populated notes
    const course = await Course.findById(id).populate({
      path: "notes",
      model: Note, // Specify the model explicitly
      populate: {
        path: "userId",
        select: "name email",
      },
    });

    if (!course) {
      return res.status(404).json({ message: "Course not found" });
    }

    return res.status(200).json({
      success: true,
      data: course,
    });
  } catch (error: any) {
    console.error("Error fetching course:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Error fetching course",
    });
  }
}
