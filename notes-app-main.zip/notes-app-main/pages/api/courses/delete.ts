import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Course from "@/models/Course";
import Category from "@/models/Category";
import Note from "@/models/Note";
import mongoose from "mongoose";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "DELETE") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    await dbConnect();
    const { id } = req.query;

    // Trouver le cours
    const course = await Course.findById(id);
    if (!course) {
      return res.status(404).json({
        success: false,
        message: "Cours non trouvé",
      });
    }

    // Supprimer toutes les notes associées
    await Note.deleteMany({ _id: { $in: course.notes } }, { session });

    // Supprimer le cours
    await Course.findByIdAndDelete(id, { session });

    // Retirer la référence du cours de la catégorie
    await Category.updateOne(
      { courses: id },
      { $pull: { courses: id } },
      { session }
    );

    await session.commitTransaction();

    return res.status(200).json({
      success: true,
      message: "Cours et notes associées supprimés avec succès",
    });
  } catch (error: any) {
    await session.abortTransaction();
    console.error("Error deleting course:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la suppression du cours",
    });
  } finally {
    session.endSession();
  }
}
