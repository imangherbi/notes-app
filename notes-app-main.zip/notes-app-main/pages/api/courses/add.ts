import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Course from "@/models/Course";
import Category from "@/models/Category";
import mongoose from "mongoose";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "POST") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const { title, categoryId, userId } = req.body;

    if (!title || !categoryId || !userId) {
      return res.status(400).json({
        success: false,
        message: "Tous les champs sont requis",
      });
    }

    // Convertir les IDs en ObjectId
    const categoryObjectId = new mongoose.Types.ObjectId(categoryId);
    const userObjectId = new mongoose.Types.ObjectId(userId);

    // Créer le cours
    const newCourse = await Course.create({
      title,
      categoryId: categoryObjectId,
      createdBy: userObjectId,
      notes: [],
    });

    // Ajouter le cours à la catégorie
    await Category.findByIdAndUpdate(categoryId, {
      $push: { courses: newCourse._id },
    });

    return res.status(201).json({
      success: true,
      message: "Cours créé avec succès",
      course: newCourse,
    });
  } catch (error: any) {
    console.error("Error creating course:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la création du cours",
    });
  }
}
