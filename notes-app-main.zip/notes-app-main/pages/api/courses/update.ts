import type { NextApiRequest, NextApiResponse } from "next";
import dbConnect from "@/lib/mongodb";
import Course from "@/models/Course";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== "PUT") {
    return res.status(405).json({ message: "Method not allowed" });
  }

  try {
    await dbConnect();
    const { id } = req.query;
    const { title } = req.body;

    if (!title) {
      return res.status(400).json({
        success: false,
        message: "Le titre est requis",
      });
    }

    const updatedCourse = await Course.findByIdAndUpdate(
      id,
      { title },
      { new: true }
    );

    if (!updatedCourse) {
      return res.status(404).json({
        success: false,
        message: "Cours non trouvé",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Cours mis à jour avec succès",
      course: updatedCourse,
    });
  } catch (error: any) {
    console.error("Error updating course:", error);
    return res.status(500).json({
      success: false,
      message: error.message || "Erreur lors de la mise à jour du cours",
    });
  }
}
