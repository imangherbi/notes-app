import React, { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import CourseSection from "@/components/CourseSection";
import { Category } from "@/types";
import { withAuth } from "@/hoc/withAuth";
import Spinner from "@/components/Spinner";
import CourseModal from "@/components/CourseModal";
import Select from "react-select";

function Dashboard() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(
    null
  );
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [isCourseModalOpen, setIsCourseModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<
    { value: string; label: string }[]
  >([]);
  const [availableTags, setAvailableTags] = useState<string[]>([]);

  const fetchCategories = async () => {
    try {
      setIsLoading(true);
      setError("");

      const user = JSON.parse(localStorage.getItem("user") || "{}");
      if (!user.id) {
        throw new Error("Utilisateur non connecté");
      }

      const response = await fetch(`/api/categories?userId=${user.id}`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message);
      }

      setCategories(data.data);
      // Ne définir la catégorie sélectionnée que s'il y a des catégories
      if (data.data && data.data.length > 0) {
        setSelectedCategory(data.data[0]);
      } else {
        setSelectedCategory(null);
      }
    } catch (error: any) {
      console.error("Error:", error);
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddCourse = async (title: string) => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      const response = await fetch("/api/courses/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          categoryId: selectedCategory?._id,
          userId: user.id,
        }),
      });

      const data = await response.json(); // Ajout de cette ligne pour récupérer les détails de l'erreur

      if (!response.ok) {
        throw new Error(data.message || "Erreur lors de la création du cours");
      }

      setIsCourseModalOpen(false);
      fetchCategories();
    } catch (error: any) {
      console.error("Error:", error);
      throw error;
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      const tags = new Set<string>();
      selectedCategory.courses?.forEach((course) => {
        course.notes?.forEach((note) => {
          note.tags?.forEach((tag) => tags.add(tag));
        });
      });
      setAvailableTags(Array.from(tags));
    }
  }, [selectedCategory]);

  const filteredCourses = selectedCategory?.courses?.filter((course) => {
    const matchesSearch =
      searchQuery.trim() === "" ||
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.notes.some((note) =>
        note.title.toLowerCase().includes(searchQuery.toLowerCase())
      );

    const matchesTags =
      selectedTags.length === 0 ||
      course.notes.some((note) =>
        note.tags.some((tag) =>
          selectedTags.some((selectedTag) => selectedTag.value === tag)
        )
      );

    return matchesSearch && matchesTags;
  });

  if (isLoading) return <Spinner />;

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={fetchCategories}
            className="px-4 py-2 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600"
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex overflow-hidden">
      <Sidebar
        categories={categories}
        selectedCategory={selectedCategory!}
        onSelectCategory={setSelectedCategory}
        onCategoriesChange={fetchCategories}
      />
      <main className="flex-1 overflow-y-auto bg-gray-100">
        <div className="p-6">
          {selectedCategory ? (
            <>
              {/* Sticky header */}
              <div className="sticky top-0 z-10 bg-gray-100 pb-4 px-3  ">
                <div className="flex mt-2 justify-between items-center mb-4">
                  <h2 className="text-2xl font-bold text-gray-800">
                    {selectedCategory.name}
                  </h2>
                  <button
                    onClick={() => setIsCourseModalOpen(true)}
                    className="px-6 py-3 bg-indigo-500 text-white rounded-lg
                      hover:bg-indigo-600 transition-colors duration-200
                      flex items-center gap-2"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M12 4v16m8-8H4"
                      />
                    </svg>
                    Add a course
                  </button>
                </div>

                {/* Search and Filters */}
                <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 rounded-lg shadow-sm">
                  <div className="flex-1">
                    <input
                      type="text"
                      placeholder="Search courses and notes..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="text-black w-full px-4 py-2 border border-gray-300 rounded-md 
                        focus:outline-none focus:ring-2 focus:ring-indigo-500 
                        focus:border-transparent"
                    />
                  </div>
                  <div className="flex-1">
                    <Select
                      isMulti
                      options={availableTags.map((tag) => ({
                        value: tag,
                        label: tag,
                      }))}
                      value={selectedTags}
                      onChange={(newValue: any) =>
                        setSelectedTags(newValue as any)
                      }
                      placeholder="Filter by tags..."
                      className="text-black  text-sm"
                      classNamePrefix="select"
                    />
                  </div>
                </div>
              </div>

              {/* Scrollable content */}
              <div className="mt-4">
                {filteredCourses && filteredCourses.length > 0 ? (
                  filteredCourses.map((course) => (
                    <CourseSection
                      key={course._id}
                      course={course}
                      onCoursesChange={fetchCategories}
                    />
                  ))
                ) : (
                  <div className="text-center mt-8 bg-white p-8 rounded-lg shadow-sm">
                    <svg
                      className="mx-auto h-12 w-12 text-gray-400"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                    <h3 className="mt-2 text-sm font-medium text-gray-900">
                      No results found
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Try adjusting your search or filter criteria
                    </p>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="text-center text-gray-500 mt-8">
              No categories available
            </div>
          )}
        </div>
      </main>

      <CourseModal
        isOpen={isCourseModalOpen}
        onClose={() => setIsCourseModalOpen(false)}
        onSubmit={handleAddCourse}
        categoryName={selectedCategory?.name || ""}
      />
    </div>
  );
}

export default withAuth(Dashboard);
