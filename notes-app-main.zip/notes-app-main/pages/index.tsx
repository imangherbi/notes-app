import Image from "next/image";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/router";

export default function HomePage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const user = localStorage.getItem("user");
    setIsAuthenticated(!!user);
  }, []);

  return (
    <div className="relative min-h-screen">
      {/* Background Image */}
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: "url('/images/dip.jpg')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          opacity: "0.25",
        }}
      />

      {/* Main Content */}
      <main className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4 py-8 ">
        <Image
          src="/images/logo.png"
          alt="Université Mohamed Khider Biskra Logo"
          width={120}
          height={120}
          className="mb-6"
        />
        <h1 className="text-4xl font-bold text-center text-white mb-4">
          Welcome to CourseNotes
        </h1>
        <p className="text-center text-white mb-6 max-w-xl">
          Organize, manage, and access your course notes effortlessly.
          {!isAuthenticated &&
            "Sign up to get started or log in if you already have an account."}
        </p>

        <div className="flex space-x-4 mb-8">
          {isAuthenticated ? (
            <button
              onClick={() => router.push("/dashboard")}
              className="px-6 py-2 text-white bg-primary rounded hover:bg-primary-light transition-colors duration-200"
            >
              Go to Dashboard
            </button>
          ) : (
            <>
              <Link
                href="/register"
                className="px-6 py-2 text-white bg-primary rounded hover:bg-primary-light transition-colors duration-200"
              >
                Sign Up
              </Link>
              <Link
                href="/login"
                className="px-6 py-2 text-white border border-white rounded hover:bg-secondary hover:text-primary hover:border-transparent transition-colors duration-200"
              >
                Log In
              </Link>
            </>
          )}
        </div>
        <section className="max-w-4xl text-center bg-black/40 p-6 rounded-lg backdrop-blur-sm">
          <h2 className="text-2xl font-semibold text-white mb-4">
            About Université Mohamed Khider Biskra
          </h2>
          <p className="text-white mb-4">
            Université Mohamed Khider Biskra is a prominent institution in
            Algeria, welcoming over 29,000 students across various disciplines.
            The university is committed to fostering innovation, research, and
            academic excellence.
          </p>
        </section>
      </main>
    </div>
  );
}
