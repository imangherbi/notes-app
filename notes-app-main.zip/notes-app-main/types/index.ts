export interface Attachment {
  filename: string;
  fileType: string;
  fileUrl: string;
  uploadedAt: Date;
}

export interface Note {
  _id: string;
  title: string;
  content: string;
  tags: string[];
  userId: string;
  attachments: Attachment[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Course {
  _id: string;
  title: string;
  categoryId: string;
  notes: Note[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Category {
  _id: string;
  name: string;
  courses: Course[];
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}
