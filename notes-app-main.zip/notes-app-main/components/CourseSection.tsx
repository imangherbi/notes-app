// components/CourseSection.tsx
import React, { useState } from "react";
import { useRouter } from "next/router";
import NoteCard from "./NoteCard";
import NoteModal from "./NoteModal";
import CourseModal from "./CourseModal";
import DeleteDialog from "./DeleteDialog";
import { Course } from "@/types";

interface CourseSectionProps {
  course: Course;
  onCoursesChange: () => void;
}

export default function CourseSection({
  course,
  onCoursesChange,
}: CourseSectionProps) {
  const router = useRouter();
  const [isExpanded, setIsExpanded] = useState(false);
  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [isCourseModalOpen, setIsCourseModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const handleAddNote = async (data: FormData) => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}");

      // Ajouter les informations nécessaires au FormData
      data.append("courseId", course._id);
      data.append("userId", user.id);

      const response = await fetch("/api/notes/add", {
        method: "POST",
        body: data,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || "Erreur lors de la création de la note"
        );
      }

      onCoursesChange();
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handleUpdateCourse = async (title: string) => {
    try {
      const response = await fetch(`/api/courses/update?id=${course._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la modification du cours");
      }

      onCoursesChange();
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handleDeleteCourse = async () => {
    try {
      const response = await fetch(`/api/courses/delete?id=${course._id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la suppression du cours");
      }

      onCoursesChange();
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handleButtonClick = (e: React.MouseEvent) => {
    e.preventDefault(); // Empêcher la navigation
    e.stopPropagation(); // Empêcher la propagation
  };

  const handleCourseClick = (e: React.MouseEvent) => {
    // Don't navigate if we're clicking inside a modal
    if (isNoteModalOpen || isCourseModalOpen || isDeleteDialogOpen) {
      return;
    }

    // Don't navigate if clicking on buttons or interactive elements
    const target = e.target as HTMLElement;
    if (
      target.tagName === "BUTTON" ||
      target.closest("button") ||
      target.closest(".modal") ||
      target.closest(".button-container") ||
      target.closest(".notes-grid")
    ) {
      return;
    }

    router.push(`/courses/${course._id}`);
  };

  return (
    <div
      onClick={handleCourseClick}
      className="bg-white shadow-lg rounded-lg p-4 sm:p-6 mb-6 cursor-pointer
        transition-all duration-200 hover:shadow-xl border border-gray-100"
    >
      {/* Header section */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h3 className="text-xl font-semibold text-gray-800">{course.title}</h3>
        <div
          className="button-container flex flex-wrap gap-2 sm:gap-3"
          onClick={(e) => e.stopPropagation()} // Stop propagation here
        >
          <button
            onClick={() => setIsNoteModalOpen(true)}
            className="px-3 sm:px-4 py-2 bg-indigo-500 text-white rounded-lg 
            shadow-sm hover:bg-indigo-600 hover:shadow-md 
            transition-all duration-200 ease-in-out text-sm sm:text-base
            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
          >
            + Add
          </button>
          <button
            onClick={() => setIsCourseModalOpen(true)}
            className="px-3 sm:px-4 py-2 bg-amber-500 text-white rounded-lg 
            shadow-sm hover:bg-amber-600 hover:shadow-md 
            transition-all duration-200 ease-in-out text-sm sm:text-base
            focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2"
          >
            Mdify
          </button>
          <button
            onClick={() => setIsDeleteDialogOpen(true)}
            className="px-3 sm:px-4 py-2 bg-rose-500 text-white rounded-lg 
            shadow-sm hover:bg-rose-600 hover:shadow-md 
            transition-all duration-200 ease-in-out text-sm sm:text-base
            focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2"
          >
            Delete
          </button>
        </div>
      </div>

      <button
        className="expand-button mt-4 text-indigo-600 hover:text-indigo-700 font-medium 
          transition-colors duration-200 flex items-center gap-2"
        onClick={(e) => {
          e.stopPropagation();
          setIsExpanded(!isExpanded);
        }}
      >
        {isExpanded ? "Hide notes" : "Show notes"}
        <svg
          className={`w-4 h-4 transform transition-transform duration-200 ${
            isExpanded ? "rotate-180" : ""
          }`}
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 9l-7 7-7-7"
          />
        </svg>
      </button>

      {isExpanded && (
        <div
          className="notes-grid mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6"
          onClick={(e) => e.stopPropagation()} // Stop propagation here
        >
          {course.notes.map((note) => (
            <NoteCard
              key={note._id}
              note={note}
              onNotesChange={onCoursesChange}
            />
          ))}
        </div>
      )}

      <div onClick={(e) => e.stopPropagation()}>
        {" "}
        {/* Wrap modals to stop propagation */}
        <NoteModal
          isOpen={isNoteModalOpen}
          onClose={() => setIsNoteModalOpen(false)}
          onSubmit={handleAddNote}
          courseTitle={course.title}
        />
        <CourseModal
          isOpen={isCourseModalOpen}
          onClose={() => setIsCourseModalOpen(false)}
          onSubmit={handleUpdateCourse}
          categoryName={course.title}
          isEditing={true}
          initialTitle={course.title}
        />
        <DeleteDialog
          isOpen={isDeleteDialogOpen}
          onClose={() => setIsDeleteDialogOpen(false)}
          onConfirm={handleDeleteCourse}
          title="Delete the course"
          message="Are you sure you want to delete the course?"
          itemToDelete={course.title}
        />
      </div>
    </div>
  );
}
