import React, { useState } from "react";
import { Note } from "@/types";
import { format, parseISO } from "date-fns";
import { enUS } from "date-fns/locale";
import DeleteDialog from "./DeleteDialog";
import NoteModal from "./NoteModal";

interface NoteCardProps {
  note: Note;
  onNotesChange: () => void;
  onClick?: () => void; // Add this prop
}

export default function NoteCard({
  note,
  onNotesChange,
  onClick,
}: NoteCardProps) {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const getFileIcon = (fileType: string) => {
    if (fileType.startsWith("image/")) return "📷";
    if (fileType.startsWith("application/pdf")) return "📄";
    return "📎";
  };

  const formatDate = (dateString: string | Date) => {
    try {
      const date =
        typeof dateString === "string" ? parseISO(dateString) : dateString;

      return format(date, "dd MMM yyyy", { locale: enUS });
    } catch (error) {
      return "Date invalide";
    }
  };

  const getAttachmentUrl = (fileUrl: string) => {
    return `/attachments/${fileUrl}`; // Construit l'URL complète
  };

  const handleUpdateNote = async (formData: FormData) => {
    try {
      const response = await fetch(`/api/notes/update?id=${note._id}`, {
        method: "PUT",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to update note");
      }

      onNotesChange();
      setIsEditModalOpen(false);
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  const handleDeleteNote = async () => {
    try {
      const response = await fetch(`/api/notes/delete?id=${note._id}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Failed to delete note");
      }

      onNotesChange();
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Error:", error);
      throw error;
    }
  };

  return (
    <>
      <div
        onClick={onClick} // Add this handler
        className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md 
        transition-all duration-200 ease-in-out border border-gray-100
        flex flex-col h-full"
      >
        <div className="flex items-start justify-between mb-3">
          <h4 className="font-semibold text-gray-800 text-lg">{note.title}</h4>
          <span className="text-xs text-gray-500">
            {formatDate(note.updatedAt)}
          </span>
        </div>

        <p className="text-sm text-gray-600 mb-4 line-clamp-3 flex-grow">
          {note.content}
        </p>

        {note.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {note.tags.map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 bg-indigo-50 text-indigo-600 rounded-lg text-xs"
              >
                {tag}
              </span>
            ))}
          </div>
        )}

        {note.attachments.length > 0 && (
          <div className="border-t border-gray-100 pt-3 mb-4">
            <p className="text-xs text-gray-500 mb-2">Pièces jointes:</p>
            <div className="flex flex-wrap gap-2">
              {note.attachments.map((file) => (
                <a
                  key={file.fileUrl}
                  href={getAttachmentUrl(file.fileUrl)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 px-2 py-1 bg-gray-50 
                    hover:bg-gray-100 rounded-lg text-xs text-gray-600
                    transition-colors duration-200"
                >
                  <span>{getFileIcon(file.fileType)}</span>
                  <span className="truncate max-w-[100px]">
                    {file.filename}
                  </span>
                </a>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-2 mt-auto pt-3">
          <button
            onClick={() => setIsEditModalOpen(true)}
            className="flex-1 px-3 py-2 bg-amber-500 text-white rounded-lg 
            shadow-sm hover:bg-amber-600 hover:shadow-md 
            transition-all duration-200 ease-in-out text-sm
            focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2"
          >
            Modify
          </button>
          <button
            onClick={() => setIsDeleteDialogOpen(true)}
            className="flex-1 px-3 py-2 bg-rose-500 text-white rounded-lg 
            shadow-sm hover:bg-rose-600 hover:shadow-md 
            transition-all duration-200 ease-in-out text-sm
            focus:outline-none focus:ring-2 focus:ring-rose-500 focus:ring-offset-2"
          >
            Delete
          </button>
        </div>
      </div>

      <NoteModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSubmit={handleUpdateNote}
        initialData={note}
        isEditing={true}
      />

      <DeleteDialog
        isOpen={isDeleteDialogOpen}
        onClose={() => setIsDeleteDialogOpen(false)}
        onConfirm={handleDeleteNote}
        title="Delete Note"
        message="Are you sure you want to delete this note?"
        itemToDelete={note.title}
      />
    </>
  );
}
