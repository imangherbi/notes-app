// components/Sidebar.tsx
import { Category } from "@/types";
import React, { useState } from "react";
import { useRouter } from "next/router";
import CategoryModal from "./CategoryModal";

interface SidebarProps {
  categories: Category[];
  selectedCategory: Category;
  onSelectCategory: (category: Category) => void;
  onCategoriesChange: () => void; // Prop pour rafraîchir les catégories
}

export default function Sidebar({
  categories,
  selectedCategory,
  onSelectCategory,
  onCategoriesChange,
}: SidebarProps) {
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const handleAddCategory = async (name: string) => {
    try {
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      const response = await fetch("/api/categories/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, userId: user.id }),
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la création de la catégorie");
      }

      // Fermer le modal et rafraîchir les catégories
      setIsCategoryModalOpen(false);
      onCategoriesChange(); // Appel de la fonction pour rafraîchir les catégories
    } catch (error) {
      console.error("Erreur:", error);
      throw error;
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("user");
    router.push("/");
  };

  return (
    <>
      {/* Burger Menu Button */}
      <button
        onClick={toggleSidebar}
        className="text-black fixed top-4 left-4 z-50 p-3 rounded-lg bg-white shadow-md hover:shadow-lg transition-all duration-200 lg:hidden"
        aria-label="Toggle Menu"
      >
        <div className="w-6 h-5 relative flex flex-col justify-between">
          <span
            className={`w-full h-0.5 bg-gray-600 rounded-full transform transition-all duration-300 
            ${isOpen ? "rotate-45 translate-y-2" : ""}`}
          />
          <span
            className={`w-full h-0.5 bg-gray-600 rounded-full transition-all duration-300 
            ${isOpen ? "opacity-0" : "opacity-100"}`}
          />
          <span
            className={`w-full h-0.5 bg-gray-600 rounded-full transform transition-all duration-300 
            ${isOpen ? "-rotate-45 -translate-y-2" : ""}`}
          />
        </div>
      </button>

      {/* Sidebar */}
      <div
        className={`fixed inset-0  bg-opacity-50 transition-opacity duration-300 lg:hidden
          ${isOpen ? "opacity-100 z-30" : "opacity-0 pointer-events-none"}`}
        onClick={toggleSidebar}
      />

      <aside
        className={`fixed top-0 left-0 h-screen w-64 bg-white shadow-lg transform transition-transform duration-300 ease-in-out z-40
          ${isOpen ? "translate-x-0" : "-translate-x-full"}
          lg:translate-x-0 lg:static lg:shadow-none`}
      >
        <div className="h-full flex flex-col bg-gray-50">
          {/* Header section with fixed height */}
          <div className="p-6 pt-16 lg:pt-6 border-b border-gray-200">
            <button
              onClick={() => setIsCategoryModalOpen(true)}
              className="w-full px-4 py-2.5 bg-indigo-500 text-white rounded-lg 
              shadow-sm hover:bg-indigo-600 hover:shadow-md 
              transition-all duration-200 ease-in-out
              focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
            >
              + Add a category
            </button>
            <h2 className="text-black text-xl text-center font-bold mt-4">
              Categories List
            </h2>
          </div>

          {/* Scrollable categories list */}
          <div className="flex-1 overflow-y-auto p-4">
            <ul className="space-y-2">
              {categories.map((category) => (
                <li
                  key={category._id}
                  onClick={() => {
                    onSelectCategory(category);
                    setIsOpen(false);
                  }}
                  className={`cursor-pointer px-4 py-3 rounded-lg transition-all duration-200 ease-in-out
                    ${
                      selectedCategory?._id === category._id
                        ? "bg-indigo-500 text-white shadow-md transform scale-102 font-medium"
                        : "text-gray-500 bg-indigo-100/50 hover:bg-indigo-500 hover:text-white "
                    }
                    group flex items-center justify-between`}
                >
                  <span className="truncate">{category.name}</span>
                  {selectedCategory?._id === category._id && (
                    <svg
                      className="w-5 h-5 ml-2"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 5l7 7-7 7"
                      />
                    </svg>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Footer section with fixed height */}
          <div className="p-4 border-t border-gray-200">
            <button
              onClick={handleLogout}
              className="w-full px-4 py-3 bg-gray-100 text-gray-700 rounded-lg 
              shadow-sm hover:bg-gray-200 hover:shadow-md 
              transition-all duration-200 ease-in-out
              focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2
              flex items-center justify-center gap-2"
            >
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
                />
              </svg>
              Déconnexion
            </button>
          </div>
        </div>
      </aside>

      <CategoryModal
        isOpen={isCategoryModalOpen}
        onClose={() => setIsCategoryModalOpen(false)}
        onSubmit={handleAddCategory}
      />
    </>
  );
}
