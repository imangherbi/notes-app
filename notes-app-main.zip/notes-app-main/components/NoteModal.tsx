import { Note } from "@/types";
import { useState, useEffect } from "react";

interface NoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: FormData) => Promise<void>;
  courseTitle?: string;
  initialData?: Note;
  isEditing?: boolean;
}

export default function NoteModal({
  isOpen,
  onClose,
  onSubmit,
  courseTitle,
  initialData,
  isEditing = false,
}: NoteModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    tags: "",
  });
  const [files, setFiles] = useState<FileList | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (isEditing && initialData) {
      setFormData({
        title: initialData.title,
        content: initialData.content,
        tags: initialData.tags.join(", "),
      });
    }
  }, [isEditing, initialData]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    // Vérifier la taille totale des fichiers (limite à 10MB par fichier)
    if (selectedFiles) {
      const invalidFiles = Array.from(selectedFiles).filter(
        (file) => file.size > 10 * 1024 * 1024
      );

      if (invalidFiles.length > 0) {
        setError("Certains fichiers dépassent la limite de 10MB");
        return;
      }
    }
    setFiles(selectedFiles);
    setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    try {
      const formDataToSubmit = new FormData();
      formDataToSubmit.append("title", formData.title);
      formDataToSubmit.append("content", formData.content);
      formDataToSubmit.append("tags", formData.tags);

      // Ajouter les fichiers
      if (files) {
        Array.from(files).forEach((file) => {
          formDataToSubmit.append("attachments", file);
        });
      }

      await onSubmit(formDataToSubmit);
      setFormData({ title: "", content: "", tags: "" });
      setFiles(null);
      onClose();
    } catch (err: any) {
      setError(err.message || "Une erreur est survenue");
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-[100] flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h2 className="text-black text-xl font-bold mb-4">
          {isEditing ? "Edit Note" : `Add Note to ${courseTitle}`}
        </h2>

        <form onSubmit={handleSubmit}>
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}

          <div className="space-y-4">
            <div>
              <label
                htmlFor="title"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Title
              </label>
              <input
                id="title"
                type="text"
                value={formData.title}
                onChange={(e) =>
                  setFormData({ ...formData, title: e.target.value })
                }
                className="text-black w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                required
              />
            </div>

            <div>
              <label
                htmlFor="content"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Content
              </label>
              <textarea
                id="content"
                value={formData.content}
                onChange={(e) =>
                  setFormData({ ...formData, content: e.target.value })
                }
                rows={4}
                className="text-black w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                required
              />
            </div>

            <div>
              <label
                htmlFor="tags"
                className="block text-sm font-medium text-gray-700 mb-1"
              >
                Tags (comma-separated)
              </label>
              <input
                id="tags"
                type="text"
                value={formData.tags}
                onChange={(e) =>
                  setFormData({ ...formData, tags: e.target.value })
                }
                placeholder="tag1, tag2, tag3"
                className="text-black w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Attachments (Max 10MB par fichier)
              </label>
              <input
                type="file"
                multiple
                accept="image/*,.pdf,.doc,.docx,.txt"
                onChange={handleFileChange}
                className="block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-md file:border-0
                  file:text-sm file:font-semibold
                  file:bg-indigo-50 file:text-indigo-600
                  hover:file:bg-indigo-100
                  focus:outline-none"
              />
              {files && files.length > 0 && (
                <div className="mt-2 space-y-1">
                  <p className="text-sm font-medium text-gray-700">
                    Fichiers sélectionnés ({files.length}):
                  </p>
                  <div className="max-h-32 overflow-y-auto">
                    {Array.from(files).map((file, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-2 text-sm text-gray-600"
                      >
                        <span>📎</span>
                        <span className="truncate">{file.name}</span>
                        <span className="text-xs text-gray-400">
                          ({(file.size / 1024 / 1024).toFixed(2)} MB)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-600 hover:text-gray-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className={`px-4 py-2 bg-indigo-500 text-white rounded-md
                hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-500
                ${isLoading ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              {isLoading
                ? "Saving..."
                : isEditing
                ? "Update Note"
                : "Create Note"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
